function X = orthogonalize(X,i)
    % Assuming X is a 3D tensor: i must be 1,2 or 3.
    
    if i == 2
        [X1,R1] = qr(left(X{1}),0);
        s = sign(diag(R1)); R1 = s.*R1; X1 = X1.*s';
        [X3,R3] = qr(X{3}',0);
        s = sign(diag(R3)); R3 = s.*R3; X3 = X3.*s';
        X3 = X3'; 
        X2 = mult_T(mult_T(R1,X{2}),R3');
    elseif i == 1
        [X3,R3] = qr(X{3}',0);
        s = sign(diag(R3)); R3 = s.*R3; X3 = X3.*s';
        X3 = X3';
        X2 = mult_T(X{2},R3');
        [X2L,R2] = qr(left(X2)',0);
        s = sign(diag(R2)); R2 = s.*R2; X2L = X2L.*s';
        X2 = reshape(X2L',size(X{2}));
        X1 = X{1}*R2';
    else
        [X1,R1] = qr(left(X{1}),0);
        s = sign(diag(R1)); R1 = s.*R1; X1 = X1.*s';
        X2 = mult_T(R1,X{2});
        [X2R,R2] = qr(right(X2),0);
        s = sign(diag(R2)); R2 = s.*R2; X2R = X2R.*s';
        X2 = reshape(X2R,size(X{2}));
        X3 = R2*X{3};
    end
    X = {X1,X2,X3};
end