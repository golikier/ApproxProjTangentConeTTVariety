function [U1,V2,V3,U2,Z2] = vecx2mat(x,param)

    n1 = param.n1; n2 = param.n2; n3 = param.n3;
    r1 = param.r1; r2 = param.r2;
    s1 = param.s1; s2 = param.s2;

    U1 = reshape(x(1:n1*s1),n1,s1);
    x(1:n1*s1) = [];
    V2 = reshape(x(1:n2*s1*r2),s1,n2,r2);
    x(1:n2*s1*r2) = [];
    V3 = reshape(x(1:n3*s2),s2,n3);
    x(1:n3*s2) = [];
    U2 = reshape(x(1:n2*r1*s2),r1,n2,s2);
    x(1:n2*r1*s2) = [];
    Z2 = reshape(x(1:n2*s1*s2),s1,n2,s2);
    x(1:n2*s1*s2) = [];
    
    assert(isempty(x))
end