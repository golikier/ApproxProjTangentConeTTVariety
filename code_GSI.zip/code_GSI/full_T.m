function Xf = full_T(X)

    X1 = X{1};
    X2 = X{2};
    X3 = X{3};
    
    Xf = mult_T(mult_T(X1,X2),X3);

end