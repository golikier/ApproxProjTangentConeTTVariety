function [P_NTCX_Y,U1V2L,U1Z2V3,U2V3R] = normal_part(Y,X)
    % This function requires that X is 2-orthogonal 
    
    n = size(Y);
    X1 = X{1};
    X3 = X{3};
    r1 = size(X1,2);
    r2 = size(X3,1);
 
    PX3 = X3'*X3;
    PX3_perp = eye(n(3))-PX3;
    PX1 = X1*X1';
    PX1_perp = eye(n(1))-PX1;
    
    XR = orthogonalize(X,3);
    XR2 = XR{2};
	XL = orthogonalize(X,1);
    XL2 = XL{2};
    
    PX2L = left(XL2)'*left(XL2);
    PX2R = right(XR2)*right(XR2)';
    PX2L_perp = eye(n(2)*r2)-PX2L;
    PX2R_perp = eye(n(2)*r1)-PX2R;

    U1Z2V3 = mult_T(PX1_perp,mult_T(Y,PX3_perp));

    U2V3R = PX2R_perp*right(mult_T(mult_T(X1',Y),PX3_perp));
    X1U2V3 = reshape(X1*reshape(U2V3R,r1,[]),n);

    U1V2L = left(mult_T(PX1_perp,mult_T(Y,X3')))*PX2L_perp;
    U1V2X3 = reshape(reshape(U1V2L,[],r2)*X3,n);

    P_NTCX_Y = X1U2V3 + U1V2X3 + U1Z2V3;

end