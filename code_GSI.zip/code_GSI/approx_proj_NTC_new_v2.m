function [PX,eta,U1,U2,V2,V3,Z2] = approx_proj_NTC_new_v2(X,U1V2L,U1Z2V3,U2V3R,s,k_max)
   % This is a slightly improved, but more computational expensive algorithm 
   % compared to the pseudo-code mentioned in the paper.
   % The if statement is removed and both parts are always executed. The
   % parameters resulting in the best angle condition are used as output.
   
    X3 = X{3}; X1 = X{1};
    n1 = size(X1,1); n3 = size(X3,2);n2 = size(U1Z2V3,2);
    r1 = size(X1,2); r2 = size(X3,1);
    
    U1Z2V3L = left(U1Z2V3); U1Z2V3R = right(U1Z2V3);
    X1U2V3R = reshape(X1*reshape(U2V3R,r1,[]),[],n3);
    U1V2X3L = reshape(reshape(U1V2L,[],r2)*X3,n1,[]);

    epsilon = 10^(-16);
    
    [U1,~,~] = svd(U1V2X3L+U1Z2V3L,'econ');
    U1 = U1(:,1:s(1));
    [~,S,V3] = svd([U2V3R;reshape((U1'*U1Z2V3L),[],n3)],'econ');
    V3 = V3(:,1:s(2))';    
    S = S(1:s(2),1:s(2));
    P = U1'*U1V2L;
    eta = norm(diag(S))^2 + norm(P(:))^2; 
    for i=2:k_max
        [U1,~,~] = svd([U1V2L,reshape((U1Z2V3R*V3'),n1,[])],'econ');
        U1 = U1(:,1:s(1));
        [~,S,V3] = svd([U2V3R;reshape((U1'*U1Z2V3L),[],n3)],'econ');
        V3 = V3(:,1:s(2))';    
        S = S(1:s(2),1:s(2));
        P = U1'*U1V2L;
        eta_new = norm(diag(S))^2 + norm(P(:))^2;
        eta(end+1) = eta_new;          
        if (eta(end) - eta(end-1))<epsilon
           break
        end
    end   
    
    [~,~,V3_2] = svd(X1U2V3R+U1Z2V3R,'econ');
    V3_2 = V3_2(:,1:s(2))';       
    [U1_2,S,~] = svd([U1V2L,left(mult_T(U1Z2V3,V3_2'))],'econ');
    U1_2 = U1_2(:,1:s(1));
    S = S(1:s(1),1:s(1));
    P = U2V3R*V3_2';
    eta2 = norm(diag(S))^2 + norm(P(:))^2;
    for i=2:k_max 
        [~,~,V3_2] = svd([U2V3R;right(mult_T(U1_2',U1Z2V3))],'econ');
        V3_2 = V3_2(:,1:s(2))';    
        [U1_2,S,~] = svd([U1V2L,left(mult_T(U1Z2V3,V3_2'))],'econ');
        U1_2 = U1_2(:,1:s(1));
        S = S(1:s(1),1:s(1));
        P = U2V3R*V3_2';
        eta_new = norm(diag(S))^2 + norm(P(:))^2;
        eta2(end+1) = eta_new;
        if (eta2(end) - eta2(end-1))<epsilon
           break
        end
    end
    
    if eta2(end) > eta(end)
        U1 = U1_2;
        V3 = V3_2;
        eta = eta2;
    end
    
    U2 = reshape(U2V3R*V3',r1,n2,s(2));
    V2 = reshape(U1'*U1V2L,s(1),n2,r2);
    Z2 = mult_T(mult_T(U1',U1Z2V3),V3');

    PX = {[X1,U1],cat(1,cat(3,U2,zeros(r1,n2,r2)),cat(3,Z2,V2)),[V3;X3]};
end