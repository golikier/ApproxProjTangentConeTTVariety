function XR = right(X)

 r = size(X);
 XR = reshape(X,[],r(end));

end