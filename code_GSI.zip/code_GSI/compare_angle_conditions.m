clear

ni = 5;
n = ni*ones(1,3);

nexp = 50;

angle_fmincon = zeros(nexp,1);
angle_K = zeros(nexp,1);
angle_new_1 = zeros(nexp,1);
angle_new_5 = zeros(nexp,1);

s = [1 1];
s1 = s(1);
s2 = s(2);
r = [1 2 2 1];
r1 = r(2);
r2 = r(3);

param.n1 = n(1);
param.n2 = n(2);
param.n3 = n(3);
param.s1 = s1;
param.s2 = s2;
param.r1 = r1;
param.r2 = r2;

save('param.mat','param')

for i=1:nexp
    
    rng(i)
    Y = randn(n);
    X = {randn(n(1),r1),randn(r1,n(2),r2),randn(r2,n(3))};
    X = orthogonalize(X,2);

    save('X.mat','X')
    fprintf('exp: %i \n',i)
    
    [~,U1V2L,U1Z2V3,U2V3R] = normal_part(Y,X);
    [PY_T,PYt_n] = tangent_space(Y,X);
    
    disp('Kutschan')
    Y_hat_K = approx_proj_NTC_Kutschan(Y,X);  
    if (Y(:)/norm(Y(:)))'*(Y_hat_K(:)/norm(Y_hat_K(:))) < (Y(:)/norm(Y(:)))'*(PY_T(:)/norm(PY_T(:)))
        Y_hat_K = PY_T;
        disp('Kutschan,tangent space')
    end
    disp(norm(Y_hat_K(:)));
    
    disp('New projection')
    Y_hat_new_1 = approx_proj_NTC_new_v2(X,U1V2L,U1Z2V3,U2V3R,s,1);
    Y_hat_new_1 = PY_T + full_T(Y_hat_new_1);   
    disp(norm(Y_hat_new_1(:)));
    
    Y_hat_new_5 = approx_proj_NTC_new_v2(X,U1V2L,U1Z2V3,U2V3R,s,5);
    Y_hat_new_5 = PY_T + full_T(Y_hat_new_5);   
    disp(norm(Y_hat_new_5(:)));
    
    disp('Fmincon')
    x0 = randn(ni*(s1+s1*r2+s2+r1*s2+s1*s2),1);
    Y_hat_fmincon = benchmark_proj_NTC(Y,X,s,x0,param);
    Y_hat_fmincon = PY_T + full_T(Y_hat_fmincon) ;
    disp(norm(Y_hat_fmincon(:)));
    
    Yn = Y(:)/norm(Y(:));
    angle_K(i) = Yn'*(Y_hat_K(:)/norm(Y_hat_K(:)));
    angle_new_1(i) = Yn'*(Y_hat_new_1(:)/norm(Y_hat_new_1(:)));
    angle_new_5(i) = Yn'*(Y_hat_new_5(:)/norm(Y_hat_new_5(:))); 
    angle_fmincon(i) = Yn'*(Y_hat_fmincon(:)/norm(Y_hat_fmincon(:)));
end

%%
set(0,'defaultAxesFontSize',24)
figure; 
gca = subplot(1,3,1);
boxplot([angle_K,angle_fmincon,angle_new_1,angle_new_5],'Widths',0.5,'Labels',{'Kutschan','fmincon','$i_{\max}=1$','$i_{\max}=5$'},'Positions',[0.5,1,1.5,2],'Widths',[0.25,0.25,0.25,0.25])
yticks([0.4,0.5,0.6,0.7,0.8])
xtickangle(45)
ylabel('$\Big\langle  \frac{\tilde{Y}}{||\tilde{Y}||} , \frac{Y}{||Y||} \Big\rangle $','Interpreter','latex')
set(gca,'TickLabelInterpreter','latex')
set(gca.Children.Children,'linewidth',1.5)

%%
exp_int = 11:20;
gca = subplot(1,3,2);
semilogy(angle_K(exp_int),'b-+','linewidth',2,'Markersize',11)
hold on
semilogy(angle_fmincon(exp_int),'r-o','linewidth',2,'Markersize',10)
semilogy(angle_new_5(exp_int),'k--+','linewidth',2,'Markersize',10)
legend('Kutschan','fmincon','$i_{\max}=5$','Interpreter','Latex')
yticks([0.4,0.5,0.6,0.7,0.8])
xlabel('10 pairs $(X,Y)$','Interpreter','Latex')
ylabel('$\Big\langle  \frac{\tilde{Y}}{||\tilde{Y}||} , \frac{Y}{||Y||} \Big\rangle $','Interpreter','latex')
set(gca,'TickLabelInterpreter','latex')
axis tight

%%
rng(28)
Y = randn(n);
X = {randn(n(1),r1),randn(r1,n(2),r2),randn(r2,n(3))};
X = orthogonalize(X,2);

[~,U1V2L,U1Z2V3,U2V3R] = normal_part(Y,X);
imax = 10;
[Y_hat_new_10,eta] = approx_proj_NTC_new_v2(X,U1V2L,U1Z2V3,U2V3R,s,imax);

gca = subplot(1,3,3);
semilogy(2:length(eta),abs(eta(2:end)-eta(1:end-1)),'b-o','linewidth',2,'Markersize',10)
xlabel('$i$','Interpreter','Latex')
ylabel('$\eta_{\mathrm{new}}-\eta_1$','Interpreter','Latex')
axis tight
yticks([10^-14,10^-12,10^-10,10^-8,10^-6,10^-4,10^-2])
xticks(1:10)
set(gca,'TickLabelInterpreter','latex')