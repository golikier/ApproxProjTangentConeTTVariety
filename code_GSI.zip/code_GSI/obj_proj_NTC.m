function f = obj_proj_NTC(x,Y)
    
    load('X.mat','X')
    load('param.mat','param')
    [U1,V2,V3,U2,Z2] = vecx2mat(x,param);
    X1 = X{1};
    X3 = X{3};
    
    E = Y - mult_T(mult_T(U1,V2),X3) - mult_T(mult_T(U1,Z2),V3) - mult_T(mult_T(X1,U2),V3);
    
    f = norm(E(:))^2;

end