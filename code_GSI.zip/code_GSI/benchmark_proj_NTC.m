function [PX,U1,V2,V3,U2,Z2] = benchmark_proj_NTC(Y,X,s,x0,param)

    s1 = s(1); s2 = s(2);
    n = size(Y);
    n1 = n(1); n2 = n(2); n3 = n(3);
    X1 = X{1}; X2 = X{2}; X3 = X{3};
    r1 = size(X1,2); r2 = size(X3,1);

    A1 = kron(eye(s1),X1'); % X1'*U1*I = 0
    A3 = kron(X3,eye(s2)); % I*V3*X3' = 0
    A4 = kron(eye(s2),right(X2)'); % X2R'*U2R*I = 0

    A_eq = cell(3,5);
    A_eq{1} = A1; A_eq{2,3} = A3; A_eq{3,4} = A4;

    sz1 = [s1*r1, s2*r2, s2*r2];
    sz2 = [s1*n1, s1*n2*r2, s2*n3, r1*n2*s2, s1*n2*s2];

    for i=1:3
        for j=1:5
            if isempty(A_eq{i,j})          
                A_eq{i,j} = zeros(sz1(i),sz2(j));
            end
        end
    end
    A_eq = cell2mat(A_eq);

    %%
    b_eq = zeros(size(A_eq,1),1);
    
    opts = optimoptions('fmincon','MaxFunctionEvaluations',10^4);
    
    x = fmincon(@(x) obj_proj_NTC(x,Y),x0,[],[],A_eq,b_eq,[],[],@constr_proj_NTC,opts);

    [U1,V2,V3,U2,Z2] = vecx2mat(x,param);
    
    PX = {[X1,U1],cat(1,cat(3,U2,zeros(size(X{2}))),cat(3,Z2,V2)),[V3;X3]};
end
