function [c,ceq] = constr_proj_NTC(x)
    load('X.mat','X')
    load('param.mat','param')

    [U1,V2,V3,U2,Z2] = vecx2mat(x,param);

    c = 0; % No inequalities.
    
    ceq = left(V2)*left(X{2})'; % V2L*X2L' = 0

    ceq1 = U1'*U1-eye(param.s1); 
    ceq2 = V3*V3'-eye(param.s2); 

    ceq = [ceq(:);ceq2(:);ceq1(:)];

end