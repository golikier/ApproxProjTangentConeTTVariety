function [PXt,PXtn] = tangent_space(Y,X)
    % Assumes that X is 2-orthogonal
    
    n = size(Y);
    
    X1 = X{1};
    X3 = X{3};
    r1 = size(X1,2);
    r2 = size(X3,1);
    
    YL = left(Y);
    YR = right(Y); 
    
    PX3 = X3'*X3;
    PX3_perp = eye(n(3))-PX3;
    PX1 = X1*X1';
    PX1_perp = eye(n(1))-PX1;
    
    XR = orthogonalize(X,3);
    XR2 = XR{2};
    
    % X2L and X3 orth
	XL = orthogonalize(X,1);
    XL2 = XL{2};
    
    PX2L = left(XL2)'*left(XL2);
    PX2R = right(XR2)*right(XR2)';

    X1W2X3 = reshape(PX1*reshape(YR*PX3,n(1),[]),n);

    X2W3R = PX2R*reshape(X1'*YL,[],n(3))*PX3_perp;
    X1X2W3 = reshape(X1*reshape(X2W3R,r1,[]),n);
    
    W1X2L = PX1_perp*reshape(YR*X3',n(1),[])*PX2L;
    W1X2X3 = reshape(reshape(W1X2L,[],r2)*X3,n);

    PXt = X1W2X3 + W1X2X3 + X1X2W3;
    
    PXtn = (norm(W1X2L(:))^2 + norm(X1W2X3(:))^2 + norm(X2W3R(:))^2);

end