function [PX,Z2,V2,V3,U1,U2] = approx_proj_NTC_Kutschan(Y,X)
    % This function implements the projection proposed in the thesis of B. Kutschan.
    % In this implementation only the normal part of the tangent cone is
    % considered of bounded TT-rank [k_1, k_2]. 
    % where k_i = r_X(i) + s_i.
    % The normal part of the tangent cone consists of three parts:
    % U_1 V_2 X_3 + U_1 Z_2 V_3 + X_1 U_2 V_3.
    % The projection of Kutschan computes these three parts seperately and
    % takes the one which has the largest inner product with Pij.
    % Assumes that X is 2-orthogonalized.
    
    YL = left(Y);
    
    n = size(Y);
    
    X1 = X{1};
    X2 = X{2};
    X2L = left(X2);
    X2R = right(X2);
    X3 = X{3};
    
    r = [size(X1,2),size(X3,1)];
    ss = [1,1];

    %% Projection on U_1 V_2 X_3, i=1, j=2
    X_tilde = mult_T(Y,X3');
    X_tildeL = left(X_tilde);
    
    X_hatL = X_tildeL - X1*X1'*X_tildeL; % n1 x n2 x r2
    X_hat = X_tilde - mult_T(X1*X1',X_tilde);
    
    X23L = reshape(X2R*X3,r(1),[]); % r1 x n2.n3
    
    S_1 = X23L*X23L'; % r1 x r1

    SA2 = (X2L'/S_1)*X2L; % n2 r_2 x n2 r2
    X_dot1 = mult_T(X_hat,X3*X3');
    X_dot1L = left(X_dot1);
    X_dot = reshape(X_hatL - X_dot1L*SA2,n(1),n(2),r(1));
    
    T_1 = X3*X3';
    T_1 = T_1*T_1;
    
    Y = mult_T(X_dot,(X3*X3'/T_1));

    i = find(abs(Y(:)) == max(abs(Y(:)))); 
    [i,j,k] = ind2sub(size(Y),i);
    
    U1_tilde = zeros(n(1),ss(1));
    V2_hat = zeros(ss(1),n(2),r(1));
         
    if Y(i,j,k) > 0
        U1_tilde(i,ss(1)) = 1;
        V2_hat(ss(1),j,k) = 1;
    else
        U1_tilde(i,ss(1)) = 1;
        V2_hat(ss(1),j,k) = -1;
    end
    
    U1 = U1_tilde - X1*X1'*U1_tilde;
    
    V2_tilde = mult_T(V2_hat,inv(T_1));
    V2_tildeL = left(V2_tilde);
    
    V2L = left(mult_T(V2_tilde,X3*X3'));
    V2 = reshape(V2_tildeL - V2L*SA2,ss(1),n(2),r(2));
    
    P12 = mult_T(X_dot,X3);
    W12 = mult_T(mult_T(U1,V2),X3);
    
    U1 = reshape(U1,1,n(1),ss(1));
    
    %% Projection on X_1 U_2 V_3 -> i=2, j=3
    X_tildeL = X1'*YL; % r1 x n2 x n3
    X_tildeR = reshape(X_tildeL,[],n(3));
    X_hatR = X_tildeR - X2R*X2R'*X_tildeR;
    
    S_1 = X3*X3';
    S = inv(S_1);
    
    X_dotR = X_hatR - X_hatR*(X3'/S_1)*X3;
    X_dotL = reshape(X_dotR,r(1),[]);
    
    Y = reshape(X1'*X1*X_dotL,r(1),n(2),n(3));
    
    i = find(abs(Y(:)) == max(abs(Y(:)))); 
    [i,j,k] = ind2sub(size(Y),i);
    
    U2_tilde = zeros(r(1),n(2),ss(2));
    V3_hat = zeros(ss(2),n(3));
        
    if Y(i,j,k) > 0
        U2_tilde(i,j,ss(2)) = 1;
        V3_hat(ss(2),k) = 1;
    else
        U2_tilde(i,j,ss(2)) = -1;
        V3_hat(ss(2),k) = 1;
    end
    
    U2_tildeR = reshape(U2_tilde,[],ss(2));
    U2 = reshape(U2_tildeR - X2R*X2R'*U2_tildeR,r(1),n(2),ss(2));
    V3_hatL = reshape(V3_hat,ss(1),[]);
    V3 = V3_hatL - V3_hatL*(X3'/S_1)*X3;
    
    P23 = reshape(X1*X_dotL,n);
    
    W23 = mult_T(mult_T(X1,U2),V3);
    
    %% Projection on U_1 Z_2 V_3 -> i=1, j=3
    X_tildeL = YL;
    X_hatL = X_tildeL - X1*X1'*X_tildeL;
    X_hatR = reshape(X_hatL,[],n(3));
    X_dot = reshape(X_hatR - X_hatR*(X3'/S_1)*X3,n);
    Y = X_dot;
    
    i = find(abs(Y(:)) == max(abs(Y(:)))); 
    [i,j,k] = ind2sub(size(Y),i);
    Z2 = zeros(ss(1),n(2),ss(2));
    U1_tilde = zeros(n(1),ss(1));    
    V3_tilde = zeros(ss(2),n(3));
     
    if Y(i,j,k) > 0
        U1_tilde(i,ss(1)) = 1;
        Z2(ss(1),j,ss(2)) = 1;
        V3_tilde(ss(2),k) = 1;
    else
        U1_tilde(i,ss(1)) = 1;
        Z2(ss(1),j,ss(2)) = -1;
        V3_tilde(ss(2),k) = 1;
    end
    
    U12 = U1_tilde - X1*X1'*U1_tilde;
    V32 = V3_tilde - V3_tilde*(X3'/S_1)*X3;
    
    P13 = X_dot;
    W13 = mult_T(mult_T(U12,Z2),V32);
    W13 = reshape(W13,n);
    
    %%
    Wij = {W12,W23,W13};
    
    inner_W_PXij = [P12(:)'*W12(:), P23(:)'*W23(:), P13(:)'*W13(:)];
   
    [m,i] = max(inner_W_PXij);
    
    if i == 1
        U2 = [];
        V3 = [];
        Z2 = [];
    elseif i == 2
        U1 = [];
        V2 = [];
        Z2 = [];
    else
        U1 = U12;
        V3 = V32;
        V2 = zeros(ss(1),n(2),r(2));
        U2 = zeros(r(1),n(2),ss(2));
    end
        
    PX = Wij{i};
    
end