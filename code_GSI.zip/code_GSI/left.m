function XL = left(X)

 s = size(X);
 
 XL = reshape(X,s(1),[]);

end